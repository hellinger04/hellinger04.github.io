// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#include <iostream>
#include <algorithm>
#include <vector>
#include "DrawPile.h"
#include "Card.h"
#include "FaceUpPile.h"

// for live game play - must not change!
void DrawPile::display() const {
  std::cout << "[XX]/" << size();
}

/* return whether the DrawPile is in shuffle mode
 */
std::string DrawPile::getRand() const {
  if (shuffle) {
    return "true";
  }
  return "false";
}

/* return string representation of DrawPile
 */
std::string DrawPile::toString() const {
  std::string result;
  // result.append("Draw ");
  result.append(std::to_string(size()));
  result.append("\n");

  // add all the pile elements to the string, at most 20 per line                                                                         
  for (int i = 0; i < size(); ++i) {
    if (i % 20 == 0 && i != 0)
      result.append("\n");
    else if (i != 0)
      result.append(" ");
    result.append(pile[i].toString());
  }
  result.append("\n");
  return result;
}

/* add completed build piles to the draw pile
 */
void DrawPile::addCompletedBuilds(DrawPile cb) {
  std::reverse(pile.begin(),pile.end());
  int cbSize = cb.size();
  for (int i = 0; i < cbSize; i++) {
    pile.push_back(cb.getTopCard());
  }
  std::reverse(pile.begin(),pile.end());
}
