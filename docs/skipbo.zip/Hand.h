// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#ifndef _HAND_H
#define _HAND_H

#include <iostream>
#include <vector>
#include "Pile.h"
#include "Card.h"

class Hand : public Pile {
  public:
    Hand() : Pile() { }
    int size() const { return pile.size(); }
    void display() const;
    std::string toString() const;
    virtual void addCard(const Card& c) { pile.push_back(c); }
    Card getCard(int index);
    void addCardAt(const Card& c, int index) { pile.insert(pile.begin() + index, c); }
};

#endif