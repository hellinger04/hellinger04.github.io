// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include "SkipBoGame.h"
#include "Hand.h"
#include "Card.h"
#include "DrawPile.h"
#include "FaceUpPile.h"
#include "Pile.h"
#include "Player.h"

using std::cout;
using std::endl;
using std::string;
using std::ifstream;

int main(int argc, char* argv[]) {
    //if number of command-line arguments is not 4 (new games) or 2 (saved games)
    if ((argc != 5) && (argc != 3)) { 
        cout << "invalid program usage: invalid number of arguments" << endl;
	return 1;
    }

    //read in shuffle argument and check validity
    std::string shuffle_as_str = argv[1];
    std::transform(shuffle_as_str.begin(), shuffle_as_str.end(), shuffle_as_str.begin(), ::tolower);
    bool shuffle;
    if (shuffle_as_str == "true") {
        shuffle = true;
    } else if (shuffle_as_str == "false") {
        shuffle = false;
    } else {
        cout << "invalid program usage: invalid first argument" << endl;
        return 1;
    }

    
    // CREATING NEW GAME
    //read in other arguments depending on argc and check validity     
    if (argc == 5) {
    	int numPlayers = std::stoi(argv[2]);
    	if ((numPlayers < 2) || (numPlayers > 6)) {
    	    cout << "invalid program usage: num players must be 2-6" << endl;
    	    return 1;
    	} else {
    	    cout << "num players is " << numPlayers << endl;
    	}
    	int stockSize = std::stoi(argv[3]);
    	if ((stockSize < 1) || (stockSize > 30)) {
	    cout << "invalid program usage: bad stock size" << endl;
	    return 1;
	} else if ((numPlayers == 6) && (stockSize > 20)) {
	    cout << "invalid program usage: bad stock size" << endl;
    	    return 1;
	} else {
            cout << "stock size is " << stockSize << endl;
        }

	//try to open specified deck
    	string deckFile = argv[4];
    	ifstream deck;
    	deck.open(deckFile);
    	if (!deck.is_open()) {
    	    cout << "invalid program usage: can't open deck file" << endl;
    	    return 1;
    	} else {
    	    SkipBoGame game(shuffle, numPlayers, stockSize);   
            if (shuffle) {
                DrawPile draw = new DrawPile(shuffle);
                game.setDeck(draw);
            } 
            game.initializeGame(deck);
            deck.close();
            game.playGame();
	}

    // LOADING SAVED GAME
    } else if (argc == 3) {
        string saveFile = argv[2];
    	ifstream savedGame;
    	savedGame.open(saveFile);

	//try to open save file
    	if (!savedGame.is_open()) {
    	    cout << "invalid program usage: can't open input game file" << endl;
    	    return 1;
    	} else {
	    SkipBoGame game;
	    //read gameplay data
	    game.readIn(savedGame);
    	    savedGame.close();
	    game.setShuffle(shuffle);
            game.playGame();
    	}
    }
}
