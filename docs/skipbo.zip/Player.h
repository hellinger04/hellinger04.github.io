// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#ifndef _PLAYER_H
#define _PLAYER_H

#include <vector>
#include <iostream>
#include "Card.h"
#include "Hand.h"
#include "FaceUpPile.h" // for stock pile

class Player {
  public:
    Player(std::string n) { name = n; }
    void readIn(std::istream & is);
    std::string toString() const;
    void display() const;
    void addToHand(const Card& c) { hand.addCard(c); }
    void addToDiscard(const Card& c, int pile_num) { discard[pile_num].addCard(c); }
    void addToStock(const Card& c) { stock.addCard(c); }
    Hand& getHand() { return hand; }
    FaceUpPile& getStock() { return stock; }
    FaceUpPile& getDiscard(int index) { return discard[index]; }

  private:
    std::string name; // Player0, Player1, etc.
    FaceUpPile stock; // TODO: check how to type derived classes
    FaceUpPile discard [4];
    Hand hand;
};

#endif
