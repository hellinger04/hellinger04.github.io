// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#ifndef _DRAWPILE_H
#define _DRAWPILE_H

#include <vector>
#include <iostream>
#include <algorithm>
#include "Card.h"
#include "Pile.h"
#include "FaceUpPile.h"

class DrawPile : public Pile {
  public:
    DrawPile() : Pile() { shuffle = false; }
    DrawPile(bool s) : Pile() { shuffle = s;}
    int size() const { return pile.size(); }
    virtual void addCard(const Card& c) { pile.push_back(c); }
    std::string toString() const;  // for saving state
    virtual void display() const;
    std::string getRand() const;
    Card getTopCard() { Card c = std::move(pile.back()); pile.pop_back(); return c; }
    void shufflePile() { std::random_shuffle(pile.begin(), pile.end()); }
    void addCompletedBuilds(DrawPile cb);
    void resetPile() { pile.clear(); }
  private:
    bool shuffle;
};

#endif
