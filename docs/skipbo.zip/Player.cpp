// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#include <iostream>
#include <string>
#include <sstream>
#include "Player.h"

// for live game play - must not change!
void Player::display() const {
  std::cout << "Current ";
  std::cout << name << ":  Stock{0}: " ;
  stock.display();
  std::cout << std::endl;
  std::cout << "   Discards{1-4}: ";
  for (int i = 0; i < 4; ++i) {
    discard[i].display();
    std::cout << "  ";
  }
  std::cout << std::endl;
  std::cout << "   Hand{5-9}: ";
  hand.display();
  std::cout << std::endl;
}

/* returns string representation of player
 * saving state format - must not change!
 * PlayerName
 * Stock size
 * 01 02 03  ...
 * ...
 * Hand size
 * 01 02 03 04 05
 * Discard1 size
 * 01 02 03 04 ...
 * ...
 * Discard2 size
 * ...
 * Discard3 size
 * ...
 * Discard4 size
 * ...
*/
std::string Player::toString() const {
  std::stringstream result;
  result << name << "\n";
  result << "Stock " << stock.toString();
  result << hand.toString();
  for (int i = 0; i < 4; ++i) {
    result << "Discard" << i << " " << discard[i].toString();
  }
  return result.str();
}

/* reads in save data for player - first reads in the
 * player's stock pile, then hand, then discard, calling
 * appropriate readIn() functions for each  
 */
void Player::readIn(std::istream & is) {
  std::string word;
  is >> word; // read in Stock
  stock.readIn(is);
  is >> word; // read in Hand
  hand.readIn(is);
  for (int i = 0; i < 4; i++) {
    is >> word; // read in Discard
    discard[i].readIn(is);
  }
}





