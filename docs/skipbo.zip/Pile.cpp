// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#include <vector>
#include "Pile.h"
#include "Card.h"

// for saving game state - must not change!
std::string Pile::toString() const {
  std::string result;
  result.append(std::to_string(size()));
  result.append("\n");
  // add all the pile elements to the string, at most 20 per line
  for (int i=0; i < size(); ++i) {
    if (i % 20 == 0 && i != 0)
      result.append("\n");
    else if (i != 0)
      result.append(" ");
    result.append(pile[i].toString());
  }
  result.append("\n");
  return result;
}

/* reads in data from saved game state. first reads in
 * first word in save game data which represents the 
 * number of cards to read. it then iterates over the
 * file for the designated number of cards, reading each
 * card and adding each to the pile
 */
void Pile::readIn(std::istream & is) {
  std::string word;
  is >> word;
  int num_cards = std::stoi(word);
  for (int i = 0; i < num_cards; i++) {
    is >> word;
    addCard(Card(std::stoi(word)));
  }
}

/* reads in data from deck file - for initializing new game
 * all decks will have 162 cards - iterate over these many
 * cards in the deck input file and add each card to the pile
 */
void Pile::readInFresh(std::istream & is) {
  int num_cards = 162;
  std::string value;
  for (int i = 0; i < num_cards; i++) {
    is >> value;
    addCard(Card(std::stoi(value)));
  }
}
