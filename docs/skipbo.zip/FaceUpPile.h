// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#ifndef _FACEUPPILE_H
#define _FACEUPPILE_H

#include <vector>
#include <iostream>
#include "Card.h"
#include "Pile.h"

class FaceUpPile : public Pile {
 public:
   FaceUpPile() : Pile() { }
   int size() const { return pile.size(); }
   virtual void addCard(const Card& c) { pile.push_back(c); }
   std::string toString() const;  // for saving state
   virtual void display() const;
   Card getTopCard();
   Card getFront();
   void resetPile() { pile.clear(); }
};

#endif
