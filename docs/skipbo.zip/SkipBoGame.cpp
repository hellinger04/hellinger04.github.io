// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#include <iostream>
#include <sstream>
#include <fstream>
#include <map>
#include <string>
#include "SkipBoGame.h"
#include "Player.h"

/* for live game play - must not change format!
 * displays draw and build piles and current player information
 *
 * drawPile  build_a  build_b  build_c  build_d
 * playerName  stock_0  
 * discards: discard_1 discard_2 discard_3 discard_4
 * hand: card_5 card_6 card_7 card_8 card_9
 */
void SkipBoGame::display() const {
    std::cout << "Draw: ";
    
    draw.display();
    std::cout << "  Build Piles: ";
    for (int j = 0; j < 4; j++) {
        build[j].display();
        std::cout << " ";
    }
    std::cout << std::endl;
    peep[curp].display();
}

/* for saving state - must not change format!
 * stores whether deck is shuffled, number of players,
 * and current player into stringstream. then iterates 
 * over players and inserts their string representations 
 * into the stringstream. finally, inserts information
 * about draw pile into stringstream.
 * 
 * shuffle numplayers currplayer
 * PlayerCurp [display]
 * PlayerCurp+1 [display]
 * [etc for all players]
 * Draw [display]
 * Build_a [display]
 * Build_b [display]
 * Build_c [display]
 * Build_d [display]
*/
std::string SkipBoGame::toString() const {
    std::stringstream result;
    std::string shuffle_as_str;
    if (shuffle) {
        shuffle_as_str = "true";
    } else {
	shuffle_as_str = "false";
    }
    result << shuffle_as_str  << " " << nump << " " << curp << "\n";
    int idx;
    for (int i = 0; i < nump; i++) {
	idx = (curp+i) % nump;
        result << peep[idx].toString();
    }
    result << "Draw " << draw.toString(); 
    for (int j = 0; j < 4; j++) {
        result << "Build_" << char('a'+j) << " ";
        result << build[j].toString();  
    }
    return result.str();
}

/* reads input from save state
 */
void SkipBoGame::readIn(std::istream & is) {
    is >> std::boolalpha >> shuffle;
    is >> nump;
    is >> curp;

    std::string word;
    for(int i = 0; i < nump; i++) {
        is >> word;
        Player player(word);
        player.readIn(is);
	if (i == 0) {
	    for (int j = 0; j < nump; j++) {
	        peep.push_back(player);
	    }
	} else {
	    peep[(curp+i)%nump] = player;
	}
    }
    is >> word; // read in Draw
    draw.readIn(is);
    for(int i = 0; i < 4; i++) {
        is >> word; // read in Build
        build[i].readIn(is);
    }
}

/* saves game to specified output file
 */
void SkipBoGame::saveGame(std::string fileName) {
    if (completed_builds.size() > 0) {
        completed_builds.addCompletedBuilds(draw);
        draw.resetPile();
        draw.addCompletedBuilds(completed_builds);
        completed_builds.resetPile();
    }
    std::ofstream saveFile;
    saveFile.open(fileName);
    saveFile << toString();
    saveFile.close();
}

/* if starting a new game, deal out the stock piles
 * to each player, one card at a time
 */
void SkipBoGame::dealCards() {
    // If starting a new game, deal out the stock piles
    for(int i = 0; i < stock_size; i++) {
        for(int j = 0; j < nump; j++) {
	       peep[j].addToStock(draw.getTopCard());
	    }
    }
}

/* re-insert cards into draw pile, reshuffling if in
 * shuffle mode
 */
void SkipBoGame::redeck() {
    for (int i = 0; i < 4; i++) {
        if (completed_builds.size() % 12 != 0) { break; }
    }

    draw.addCompletedBuilds(completed_builds);
    completed_builds.resetPile();
    if (shuffle) { draw.shufflePile(); }
}

/* fill current player's hand with specified
 * number of cards
 */
void SkipBoGame::fillHand(int num) {
    for(int i = 0; i < num; i++) {
        if (draw.size() == 0) { redeck(); }
        peep[curp].addToHand(draw.getTopCard());
    }
}

/* begins new skipbo game
 * randomly determine which player goes first, modulus 
 * operator allows us to wrap around array of players
 * assign name to and construct each player, then add
 * to array of players. after all players created,
 * deal cards
 */
void SkipBoGame::initializeGame(std::istream & deckFile) {
    draw.readInFresh(deckFile);
    // shuffle current player here if necessary
    curp = ((shuffle) ? std::rand() % nump : 0);
    int idx;
    for (int i = 0; i < nump; ++i) {
        std::stringstream name;
        idx = (curp+i) % nump;
        name << "Player" << idx;
        Player player(name.str());
        peep.push_back(player);
    } 
    if (shuffle) { draw.shufflePile(); }
    dealCards();
}

/* function adds a given card back to start pile if invalid
 * move is attempted. if the card was taken from the stock 
 * pile, add it back there. if card taken from a discard pile,
 * add it back there. if the card was taken from player's hand,
 * add it back there. if none of these are the case, start 
 * command is invalid, throw error
 */
void SkipBoGame::addCardBackToStart(Card card, int start) {
    if (start == 0) {
        peep[curp].getStock().addCard(card);
    } else if (start > 0 && start < 5) {
        peep[curp].getDiscard(start-1).addCard(card);
    } else if (start > 4 && start < 10) {
        peep[curp].getHand().addCardAt(card, start-5);
    }
    throw "illegal command, try again";
}

/* sets aside full build piles by adding it to the completed_builds pile
 */
void SkipBoGame::holdOut(int pos, char e) {
    for (int i = 0; i < 12; i++) {
        completed_builds.addCard(build[pos].getFront());
    }
    build[pos].resetPile();
    std::cout << "build pile " << e << " full, set aside" << std::endl;
}

/* get card from specified start pile. if start pile is
 * the stock pile, remove top card from there. if trying 
 * to take card from discard pile, first check whether 
 * specified discard pile is empty - if empty, throw error.
 * otherwise, remove top card from specified discard pile.
 * if trying to take card from hand, remove card at that 
 * position from hand. if start index is invalid, throw error.
 */
Card SkipBoGame::startPile(int start) {
    Card card;
    if (start == 0) {
        card = peep[curp].getStock().getTopCard();
    } else if (start > 0 && start < 5) {
        if (peep[curp].getDiscard(start).size() == 0) {
            throw "illegal command, try again";
        }
        card = peep[curp].getDiscard(start - 1).getTopCard();
    } else if (start > 4 && start < 10) {
        card = peep[curp].getHand().getCard(start - 5);
    } else {
        throw "illegal command, try again";
    }
    return card;
}

/* try to add card to specified end pile, return integer to 
 * represent whether player's turn is over. first, create a map 
 * to easily convert from char to integer. if trying to put 
 * card in discard pile, first check whether the card is 
 * originating from the stock pile - if so, throw an error. 
 * otherwise, add the card to the specified discard pile and
 * set stop to 1 to represent the end of player's turn.
 *
 * if trying to put card in build pile, first determine the
 * value of the top build pile card, and verify that the 
 * card can be validly added to the top of this build pile.
 * if it can, add the card to the build pile. if the build
 * pile is full after this addition, call holdOut to remove
 * the build pile.
 *
 * if the end index is not valid, throw an error
 */
int SkipBoGame::endPile(Card card, char e, int start) {
    std::map<char, int> mapChars = {{'a', 0}, {'b', 1}, {'c', 2}, {'d', 3}};
    int stop = 0;
    if (e > '0' && e < '5') {
        if (start == 0) {
            peep[curp].addToStock(card);
            throw "illegal command, try again";
        }
        peep[curp].getDiscard(e-'0'-1).addCard(card);
        stop = 1;
    } else if (e >= 'a' && e <= 'd') {
        int buildVal;
        if (build[mapChars[e]].size() == 0) {
            buildVal = 0;
        } else {
            buildVal = build[mapChars[e]].size();
        }
        int cardVal = card.getValue();
        if (cardVal == 0) { cardVal = buildVal + 1; }
        if (cardVal == (buildVal + 1)) {
            build[mapChars[e]].addCard(card);
        } else {
            addCardBackToStart(card, start);
        }
        if (build[mapChars[e]].size() == 12) { holdOut(mapChars[e], e); }
    } else {
        addCardBackToStart(card, start); // add card back to start pile if end not valid
    }
    return stop;
}

/* this function moves a card from a start to an end pile
 * first, get the integer value of input char. then try to 
 * get the card from the start pile and insert it onto the 
 * endpile. catch an out_of_range exception - represents 
 * invalid input by user. also catch custom message exception
 * return whether player's turn is over (if they discarded)
 */
int SkipBoGame::moveCard(char s, char e) {
    int start = s - '0';
    int stop = 0;
    Card card;
    try { 
        card = startPile(start);
        stop = endPile(card, e, start);
    } catch (const std::out_of_range& e){
        std::cout << "illegal command, try again" << std::endl;
        return 0;
    } catch (const char* msg) {
        std::cout << msg << std::endl;
        return 0;
    }
    return stop;
}

/* function runs until player validly discards a card 
 * allows each player to complete their move. outputs 
 * message to user and stores their response, determines
 * whether to move or discard based on first char of 
 * response. tries to execute player's requested move -
 *
 * if player wants to move a card, first check if response 
 * is missing start and end details - if so, throw error. 
 *
 * if player wants to discard, first check whether their 
 * hand is empty - if it is, draw more cards for the player
 * 
 * if first char of response is not 'm' or 'd,' it is invalid,
 * throw an exception. return whether the player's turn is over
 */
int SkipBoGame::playerMove() {
    int stop = 0;
    char choice;
    std::string start;
    std::string end;
    bool proceed = true;
    while(proceed) {
        std::cout << "(m)ove [start] [end] or (d)raw ? ";
        std::string response;
        std::cin >> response;
	choice = response.at(0);
        try {
    	    switch(choice) {
                case 'm':
		    std::cin >> start >> end;
                    if (start.empty() || end.empty()) {
                        throw "invalid number of arguments";
                    }
        		    if (start.length() != 1 || end.length() != 1) {
        	            throw "invalid number of arguments";
        		    }
                    stop = moveCard(start[0], end[0]);
                    proceed = false;
                    break;
                case 'd': proceed = false;
                    if (peep[curp].getHand().size() == 0){
                        fillHand(5);
                    } else {
                        throw "illegal command, try again";
                    }
                    break;
                default: 
                    throw "illegal command, try again";
            }
    	} catch (const char* msg) {
    	    std::cout << msg << std::endl;
    	}
    }
    return stop;
}

/* asks player if they would like to continue playing, taking
 * appropriate action based on their response. if player would 
 * like to continue playing, end loop. if player would like to 
 * save the game, prompt user for save file and then call saveGame
 * on the specified filename. if player would like to quit, print
 * goodbye message and end program by throwing exception. 
 */
void SkipBoGame::gameStatus() {
    bool proceed = true;
    char choice;
    std::string filename;

    while(proceed) {
        std::cout << "\n >> Player" << curp << " turn next" << std::endl;
        std::cout << "(p)lay, (s)ave, or (q)uit ? ";
        std::cin >> choice;
        switch(choice) {
            case 'p':
                proceed = false;
                break;
            case 's':
                redeck();
                std::cout << "save filename: ";
                std::cin >> filename;
                redeck();
		saveGame(filename);
                throw "quit game";
            case 'q':
                std::cout << "thanks for playing" << std::endl;
                throw "quit game";
            default:
                std::cout << "illegal command, try again" << std::endl;
                break;
        }
    }

}

/* function manages each player's turn, calling other helper functions
 * if the current player's hand is less than 5, fill their hand. until
 * player discards, display current game status to player and call
 * playerMove(). after each move, check if the player's stock size is 
 * empty - if so, declare the current player as the winner and end game 
 * after turn is over, display current game status again
 */ 
void SkipBoGame::playerTurn() {
    if (peep[curp].getHand().size() < 5){ fillHand(5-peep[curp].getHand().size()); }
    int stop = 0;
    while (stop == 0) {
        display();
        stop = playerMove();
        if (peep[curp].getStock().size() == 0) {
            std::cout << "\nGAME OVER - Player" << curp << " wins!" << std::endl;
            throw "end game";
        }
        std::cout << std::endl;
    }
    display();
}

/* function manages entire game, managing current player and calling
 * helper functions to complete gameplay functionality. first prints 
 * details about which player's turn is next, and asks player whether
 * they would like to continue the game. it then calls playerTurn()
 * to manage the current player's turn, if the player would like to 
 * continue playing. after the player's turn, the function increments
 * current player, using modulus to wrap around the array to the first
 * player if necessary. catch any errors thrown by playerTurn or gameStatus
 * and return to main
 */ 
int SkipBoGame::playGame() {
    while(true) {
        try {
            gameStatus();
            playerTurn();
            curp = (curp + 1) % nump;
        } catch (const char* msg) {
            return 0;
        }
    }
    return 0;
}

