// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#include <iostream>
#include "FaceUpPile.h"

// for live game play - must not change!
void FaceUpPile::display() const {
  if (size()) {
    pile[pile.size()-1].display();
  }
  else std::cout << "--";
  std::cout << "/" << size();
}

// for saving game state - must not change!
std::string FaceUpPile::toString() const {
  std::string result;
  result.append(std::to_string(size()));
  result.append("\n");
  // add all the pile elements to the string, at most 20 per line
  for (int i=0; i < size(); ++i) {
    if (i % 20 == 0 && i != 0)
      result.append("\n");
    else if (i != 0)
      result.append(" ");
    result.append(pile[i].toString());
  }
  result.append("\n");
  return result;
}

/* getter method removes and returns top card of FaceUpPile
 */
Card FaceUpPile::getTopCard() {
    Card c = std::move(pile.back());
    pile.pop_back();
    return c;
}

/* getter method removes and returns the bottom card of FaceUpPile
 */
Card FaceUpPile::getFront() {
    Card c = std::move(pile.front());
    pile.erase(pile.begin());
    return c;
}
