// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#include <iostream>
#include "Hand.h"

/*************************************
For SkipBo - Fall 2018 - EN.601.220
Instructor provided code
*************************************/

// for live game play - must not change!
void Hand::display() const {
  int i;
  for (i = 0; i < size(); i++) {
    pile[i].display();
    std::cout << "  ";
  }
  for ( ; i < 5; i++)
    std::cout << "--  ";
}

// for saving game state - must not change!
std::string Hand::toString() const {
  std::string result;
  result.append("Hand ");
  result.append(std::to_string(size()));
  result.append("\n");

  // add any hand elements to the string
  for (int i = 0; i < size(); ++i) { //prepend or postpend? 
    if (i != 0) {
      result.append(" ");
    }
    result.append(pile[i].toString());
  }

  result.append("\n");
  return result;
}

/* getter function returns the card at a given hand index
 */
Card Hand::getCard(int index) {
  Card c = pile.at(index);
  pile.erase(pile.begin() + index);
  return c; 
}
