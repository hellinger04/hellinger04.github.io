// Darius Irani, dirani2, Clara Liff, Andrew Hellinger

#ifndef _SKIPBOGAME_H
#define _SKIPBOGAME_H

#include <iostream>
#include <vector>
#include "DrawPile.h"
#include "FaceUpPile.h"
#include "Player.h"

class SkipBoGame {
  public:
    SkipBoGame() { }
    SkipBoGame(bool sh, int n) { shuffle = sh; nump = n; } // figure out constructor for loading in saved game
    SkipBoGame(bool sh, int n, int s) { shuffle = sh; nump = n; stock_size = s; }
    void readIn(std::istream & is);
    std::string toString() const;
    void display() const;
    void initializeGame(std::istream & deckFile);
    int playGame();
    void dealCards();
    void playerTurn();
    void fillHand(int num);
    void setShuffle(bool b) { shuffle = b; }
    void saveGame(std::string fileName);
    int moveCard(char s, char e);
    void gameStatus();
    int playerMove();
    Card startPile(int start);
    int endPile(Card card, char e, int start);
    void addCardBackToStart(Card card, int start);
    void holdOut(int pos, char e);
    void setDeck(DrawPile d) { draw = d; }
    void redeck();

  private:
    bool shuffle;
    DrawPile draw;
    FaceUpPile build [4];
    DrawPile completed_builds;
    std::vector<Player> peep;
    int curp; // Current player
    int nump; // Number of players 
    int stock_size;
};


#endif
